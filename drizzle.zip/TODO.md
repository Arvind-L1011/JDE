- [ ] Inspect current OAuth/cookie related server code
- [ ] Add `app.set("trust proxy", 1)` in `server/_core/index.ts`
- [ ] Update `server/_core/cookies.ts` production cookie settings for SameSite=None+Secure
- [x] Run typecheck/lint/tests (if available)

- [ ] Redeploy and verify OAuth sign-in lands on dashboard (/)

